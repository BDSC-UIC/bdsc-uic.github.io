function [ index score lbda ] = chooseLambda(X, num, perplexity)
% Choose lambda by binary search so that abs(N(0.9) -  num) <= tol

[nSamp nFeat] = size(X);
if nargin < 3
        perplexity = 0.03*nSamp;
end
    
minVal = 1e-5;
maxVal = 100;

% One could use a smaller value for tol (e.g., tol = 1 or tol = 2)
% if more running time is avaiable

tol = 5;
while (maxVal-minVal) > 1e-5
    lbda = (minVal + maxVal)/2;
    [index score] = snfs(X, lbda, perplexity);
    if (abs(num - sum(score>0.9)) <= tol)
        break;
    elseif (sum(score>0.9) > num)
        minVal = lbda;
    else
        maxVal = lbda;
    end
end
    
fprintf('lambda = %f, N(0.9) = %d\n', lbda, sum(score>0.9));

end

