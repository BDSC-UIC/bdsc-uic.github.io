function [ sigma ] = findSigma(X, perplexity)

[nSamp nFeat] = size(X);
sigmaMin = 0;
sigmaMax = 1e+5;

tol = 0.01;
val = log(perplexity);
while abs(sigmaMax - sigmaMin) > tol
    sigma = (sigmaMin + sigmaMax)/2;
    Xnew = X/sigma;
    S = Xnew*Xnew';
    S = exp(S);
    S(1:nSamp+1:end) = 1e-5;
    P = max(bsxfun(@rdivide, S, sum(S, 2)), realmin);
    P = -P.*log(P);
    if (mean(sum(P, 2)) > val)
        sigmaMax = sigma;
    else
        sigmaMin = sigma;
    end
end

end

