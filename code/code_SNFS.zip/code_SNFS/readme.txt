Code for Unsupervised Feature Selection by Preserving Stochastic Neighbors

snfs.m: It implements SNFS and the optimization requires the toolkit by Mark Schmiht (https://www.cs.ubc.ca/~schmidtm/Software/minConf.html).
chooseLambda.m: N(0.9) is a monotonically non-increasing function of lambda. If one wants to select n features, he can choose the lambda that makes N(0.9) equal or close to n by binary search. 
test.m: Examples to run the code.

Suggestion on parameters:
In unsupervised feature selection, class labels should be not used to tune the parameters. So we provide the following suggestions on choosing the parameters.
i. perplexity: we found using perplexity = 2~5% * total # of data points usually gives decent results. By default, the code uses (3% * total # of data points).
ii. lamba: Choose lambda based on how many features you want to retain by using chooseLamba.m.
iii. Normalization: It is recommended to normalize the row to unit length which usually helps improve the performance (Line 9 and 10 in snfs.m). (In the original paper we didn't do the normalization)
