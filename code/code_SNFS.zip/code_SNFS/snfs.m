function [ index score] = snfs(X, lbda, perplexity )
    
    [nSamp nFeat] = size(X);
    if nargin < 3
        perplexity = 0.03*nSamp;
    end

    % It is usually preferrable to normalize each row to unit length
    X = bsxfun(@rdivide, X, sqrt(sum(X.*X, 2)));
    X(isnan(X)) = 0;
        
    sigma = findSigma(X, perplexity);
    X = X/sigma;
    S = X*X';
    S = exp(S);
    S(1:nSamp+1:end) = 1e-5;
    P = max(bsxfun(@rdivide, S, sum(S, 2)), realmin);

    w = ones(nFeat, 1);
    LB = zeros(nFeat, 1);
    UB = ones(nFeat, 1);
    options.maxIter = 20;
    score = minConf_TMP(@(w)funObj(w, X, P, lbda), w, LB, UB, options);

    [jnk index] = sort(-score);
    fprintf('N(0.9): %d\n', sum(score>0.9));

end

function [ f gr] = funObj(w, X, P, lbda)
    [nSamp, nFeat] = size(X);

    S = X*diag(w)*X';
    S = exp(S);
    S(1:nSamp+1:end) = 1e-5;                                                 % set diagonal to zero
    Q = max(bsxfun(@rdivide, S, sum(S, 2)), realmin);
    Q(isnan(Q)) = 1e-5;
    
    tmp = (P-Q);
    d = P.*log(P./Q);
    %d(d==Inf) = 0;
    %d(isnan(d)) = 0;
    %w(isnan(w)) = 0;
    f = lbda*sum(w) + sum(sum(d, 1));
        
    gr = zeros(nFeat, 1) + lbda;
    for i = 1:nFeat
        gr(i) = gr(i) - X(:, i)'*tmp*X(:, i); 
    end
        
end


