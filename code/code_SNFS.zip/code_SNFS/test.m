load('handwritten.mat');

[pixelSNFS score] = snfs(pixel, 1.0);

% pixelSNFS is the index of features ranked by SNFS
[pixelSNFS score lbda] = chooseLambda(pixel, 100);