function [ selectFeat w lbdas] = cdmaFS(Xs, featNumCandidate, alpha)
% Xs: feature matrices (Xs{1}, Xs{2}, …) for different views
% featNumCandidate: e.g., [100, 200, 300, 400]
% alpha: optional(default is 0.01), regularization used in cross diffusion
numViews = size(Xs, 1);
if nargin < 3
    alpha = 0.01;
end

G = crossDiffusion(Xs, alpha);
% choose lambda to make # of selected features close to featureNum in featureNumCandidate
[selectFeat, w, lbdas] = chooseLambdaBatch(Xs, G, featNumCandidate);

end
