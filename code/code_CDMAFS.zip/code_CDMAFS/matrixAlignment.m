function [index w] = matrixAlignment(X, G, lbda)

[nSamp nFeat] = size(X);
Xnew = X./repmat(sqrt(sum(X.*X, 2)), 1, nFeat);
Xnew(isnan(Xnew))=0;

C = eye(nSamp) - 1/nSamp*ones(nSamp, 1)*ones(1, nSamp);

wInit = ones(nFeat, 1);

option = {};
option.maxIter = 20;
option.verbose = 0;
w = minConf_PQN(@(w)funObj(w, Xnew, G, C, lbda), wInit, @(w)funProj(w), option);

[jnk index] = sort(-w);

end

function [ f gr] = funObj(w, X, Ky, C, lbda)
    
    [nSamp, nFeat] = size(X);
    
    w(isnan(w)) = 0;
    Xw = X*diag(w); 
    
    sumXw = sum(Xw.^2, 2);
    xwx = Xw*Xw';
    Kx = exp(-bsxfun(@plus, sumXw, bsxfun(@plus, sumXw', -2*Xw*Xw')));

    Kx(1:nSamp+1:end) = 0;
    Kx(isnan(Kx)) = 0;
    
    v = (C*Ky*C).*Kx;
    
    f = lbda*sum(w) - sum(sum(v));
    
    gr = zeros(nFeat, 1) + lbda;
    for i = 1:nFeat
         gr(i) = gr(i) + 2*w(i)*sum(sum(v.*(bsxfun(@minus, X(:, i), X(:, i)')).^2));
    end
    
    %fprintf('reach bound: %d\n', (sum(w==0) + sum(w==1))/nFeat);
end

function [ wnew] = funProj(w)
    wnew = min(max(w, 0), 1);
end

