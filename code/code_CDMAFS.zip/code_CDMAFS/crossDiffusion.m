function [ G ] = crossDiffusion(Xs, alpha)

numViews = size(Xs, 1);
k = 5;

Ks = cell(numViews, 1);
for i = 1:numViews
    X = Xs{i};
    [nSamp nFeat] = size(X);
    Xnew = X./repmat(sqrt(sum(X.*X, 2)), 1, size(X, 2));
    Xnew(isnan(Xnew)) = 0;

    options.WeightMode = 'Binary';
    options.k = 5;
    Ks{i} = constructW(Xnew, options);

    Ks{i} = Ks{i}./repmat(sum(Ks{i}, 2), 1, nSamp);
    Ks{i}(isnan(Ks{i})) = 0;
end


[P Ps] = diffusionProcess(Ks, alpha);

[Pt index] = sort(-P, 2);

G = zeros(nSamp, nSamp);
for i = 1:nSamp
    G(i, index(i, 1:k)) = 1;
end

G = (G+G')>0;

end

