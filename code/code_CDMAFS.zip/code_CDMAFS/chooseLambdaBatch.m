function [selectFeat, w, lbdas] = chooseLambdaBatch(Xs, G, featNumCandidate)

numViews = size(Xs, 1);
selectFeat = cell(size(featNumCandidate, 2), numViews);
w = cell(size(featNumCandidate, 2), numViews);
lbdas = zeros(size(featNumCandidate, 2), 2);

for v = 1:numViews
    minlbda = 0.000001;
    maxlbda = 10;
    iter = 1;
    for featN = featNumCandidate
        if iter >= 2
            maxlbda = lbdas(iter-1, v);
        end
        [selectFeat{iter}{v}, w{iter}{v}, lbdas(iter, v)] = chooseLambda(Xs{v}, G, featN, minlbda, maxlbda);
        iter = iter + 1;
    end
end



end