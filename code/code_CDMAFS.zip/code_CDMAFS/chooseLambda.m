function [ selectFeat score lbda ] = chooseLambda(X, G, num, minlbda, maxlbda)

selectFeat = [1];
score = [1];
lbda = 1;

cur_min = 10000;
tol = 10;
while (maxlbda - minlbda) > 0.0001
    lbda = (minlbda + maxlbda)*0.5;
    [index score] = matrixAlignment(X, G, lbda);
    sum(score==1)
    if abs(sum(score==1)-num) < abs(cur_min-num)
        cur_min = sum(score==1);
        selectFeat = index(1:sum(score==1));
    end
    if abs(sum(score==1) - num) < tol
        selectFeat = index(1:sum(score==1));
        break;
    elseif sum(score==1) > num
        minlbda = lbda;
    else
        maxlbda = lbda;
    end

end

if (abs(size(selectFeat)-num) > tol)
    fprintf('failed to find lambda for feature number %d+-%d, the closest feature size found is %d\n', num, tol, cur_min);
end

end
