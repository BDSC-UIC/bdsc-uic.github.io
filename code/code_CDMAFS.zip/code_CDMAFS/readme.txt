Code for Multi-view Unsupervised Feature Selection by Cross-diffused Matrix Alignment
Author: Xiaokai Wei, weixiaokai@gmail.com

cdmaFS: It implements CDMA-FS and it can choose appropriate lambda for given number of selected features by using chooseLambdaBatch. For optimization, it requires the toolkit by Mark Schmiht (https://www.cs.ubc.ca/~schmidtm/Software/minConf.html). It also requires constructW.m from http://www.cad.zju.edu.cn/home/dengcai/Data/code/constructW.m

Bibtex:
@inproceedings{Wei_multiviewfs,
  author    = {Xiaokai Wei and
               Bokai Cao and
               Philip S. Yu},
  title     = {Multi-view unsupervised feature selection by cross-diffused matrix
               alignment},
  booktitle = {2017 International Joint Conference on Neural Networks, {IJCNN} 2017,
               Anchorage, AK, USA, May 14-19, 2017},
  pages     = {494--501},
  year      = {2017}
}


 
