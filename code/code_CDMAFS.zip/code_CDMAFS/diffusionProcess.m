function [ P Ps ] = diffusionProcess(Ks, alpha)

iter = 1;
maxIter = 20;

numViews = size(Ks, 1);
nSamp = size(Ks{1}, 1);

Ps = cell(size(Ks));
P_p = Ks;
while iter <= maxIter
    for i = 1:numViews
        P_m = 0;
        for j = 1:numViews
            if i ~= j
                P_m = P_m + P_p{j};
            end
        end
        P_m = P_m/(numViews-1);
        
        Ps{i} = Ks{i}*P_m*Ks{i}' + alpha*eye(size(Ks{1}, 1));
    end

    
    P_p = Ps;
    
    iter = iter + 1;
end

P = 0;
for i = 1:numViews
    P = P + Ps{i};
end
P = P/numViews;
P(1:nSamp+1:end) = 0;

end

