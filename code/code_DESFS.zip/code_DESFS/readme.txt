ht_des: hypothesis testing based des
cl_des: classification based des

It uses the function constructW.m from http://www.cad.zju.edu.cn/home/dengcai/Data/code/constructW.m

For examples using ht_des and cl_des, one can refer to exampleRun.m

