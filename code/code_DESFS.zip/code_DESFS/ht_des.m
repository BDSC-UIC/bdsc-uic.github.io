function [ index ] = ht_des(X)
% X: n*D matrix

[nSamp nFeat] = size(X);

X = (X-repmat(min(X), nSamp, 1))./(repmat(max(X), nSamp, 1)-repmat(min(X), nSamp, 1));
X(isnan(X)) = 0;

Xnew = X./repmat(sqrt(sum(X.*X, 2)), 1, nFeat);
Xnew(isnan(Xnew)) = 0;

options.WeightMode = 'Binary';
options.k = 5;
options.bTrueKNN = 1;
G = constructW(Xnew, options);

sscore = zeros(1, nFeat);
dscore = zeros(1, nFeat);


maxIter = 40000;
iter = 1;
while iter <= maxIter
    i = randsample(nSamp, 1);

    if mod(iter, 2) == 0
        neighbors = find(G(i, :) == 1);
        while (size(neighbors, 2) < 1)
            i = randsample(nSamp, 1);
            neighbors = find(G(i, :) == 1);
        end
        j = neighbors(randi([1 size(neighbors, 2)]));
        
        xi = X(i, :);
        xj = X(j, :);
        
        sscore = sscore + xi.*xj;
    else
        j = i;
        while j == i || G(i, j) == 1
            j = randsample(nSamp, 1);
        end
        
        xi = X(i, :);
        xj = X(j, :);

        dscore = dscore + xi.*xj;
    end
    
    iter = iter + 1;
end


sscore = 2*sscore/maxIter;
dscore = 2*dscore/maxIter;

prob = (sscore+dscore)/2;
se = sqrt(prob.*(1-prob)*(4/maxIter));

score = (sscore - dscore)./se;

[jk index] = sort(-score);

end

