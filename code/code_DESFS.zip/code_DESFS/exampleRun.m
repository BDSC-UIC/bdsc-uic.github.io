load 'cnn10';
index = cl_des(cFea, 0.0001);
% clustering using top 200 features
clustering(cLabel, cFea(:, index(1:200)), 7);
% clustering using top 400 features
clustering(cLabel, cFea(:, index(1:400)), 7);

index = ht_des(cFea);
clustering(cLabel, cFea(:, index(1:400)), 7);