function [ index score] = cl_des(X, lbda)
% X: n*D matrix

[nSamp nFeat] = size(X);

X = (X-repmat(min(X), nSamp, 1))./(repmat(max(X), nSamp, 1)-repmat(min(X), nSamp, 1));
X(isnan(X)) = 0;

Xnew = X./repmat(sqrt(sum(X.*X, 2)), 1, nFeat);
Xnew(isnan(Xnew)) = 0;

options.WeightMode = 'Binary';
options.k = 5;
options.bTrueKNN = 1;
G = constructW(Xnew, options);

w = zeros(nFeat, 1)';
stepsizeinit = 1;

stepsize = 1;
count = zeros(nFeat, 1)';


rand('twister',5489);

maxIter = 40000;
iter = 1;
while iter <= maxIter
    i = randsample(nSamp, 1);

    stepsize = stepsizeinit/(iter.^0.5);
    
    v = rand();
    if v >= 0.5
        neighbors = find(G(i, :) == 1);
        while (size(neighbors, 2) < 1)
            i = randsample(nSamp, 1);
            neighbors = find(G(i, :) == 1);
        end
        j = neighbors(randi([1 size(neighbors, 2)]));
        
        xi = X(i, :);
        xj = X(j, :);

        t = xi.*xj;
        s = sum(t.*w);

        if s < 1
            w = w - stepsize*(-t);
        end
    else
        j = i;
        while j == i || G(i, j) == 1
            j = randsample(nSamp, 1);
        end
        
        xi = X(i, :);
        xj = X(j, :);
    
        t = xi.*xj;
        s = sum(t.*w);
        
        if s > -1
            w = w - stepsize*(t);
        end
    end
    
    w = w - stepsize*lbda*sign(w);

    iter = iter + 1;
end

score = w;
[jnk index] = sort(-score);

end

